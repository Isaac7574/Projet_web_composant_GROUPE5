package com.projetwuri.alimentation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlimentationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlimentationApplication.class, args);
	}

}
