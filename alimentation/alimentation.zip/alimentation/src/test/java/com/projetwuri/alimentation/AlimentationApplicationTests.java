package com.projetwuri.alimentation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlimentationApplicationTests {

	@Test
	void contextLoads() {
	}

}
